#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun  1 09:25:20 2022

@author: zjc
"""
import cv2
a=cv2.imread('000002.jpg')